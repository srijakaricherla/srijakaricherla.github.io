# Data Engineer Portfolio

Responsive personal portfolio website.

## Preview
Open `index.html` in your browser.

## GitHub Pages
Create a public repository, upload `index.html`, `styles.css`, and `script.js` to the repository root. Under Settings → Pages, choose Deploy from a branch, `main`, `/ (root)`.

## Before publishing
Verify all employment history, dates, metrics, location, and credentials against your resume. The content is taken from your supplied HTML.
